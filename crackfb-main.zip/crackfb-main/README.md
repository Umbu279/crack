git clone https://github.com/YusepXD/crackfb

cd crackfb

python son.py
